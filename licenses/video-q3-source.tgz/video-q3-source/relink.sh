#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "$0")" && pwd -P)"
cd "$ROOT"
command -v emcc >/dev/null || { echo 'Activate compatible Emscripten 4.0.15 first.' >&2; exit 1; }
test -f sources/FFmpeg-140fd653aed8cad774f991ba083e2d01e86420c7/libavcodec/avcodec.h || { echo 'Extract the shared FFmpeg archive into sources/ first.' >&2; exit 1; }
mkdir -p output
cp configuration/avconfig.h configuration/ffversion.h sources/FFmpeg-140fd653aed8cad774f991ba083e2d01e86420c7/libavutil/
emcc relink/bridge.c relink/libavcodec.a relink/libavutil.a -Isources/FFmpeg-140fd653aed8cad774f991ba083e2d01e86420c7 \
 -s MODULARIZE=1 -s EXPORT_ES6=1 -s ALLOW_MEMORY_GROWTH=1 -s INITIAL_MEMORY=33554432 -s MAXIMUM_MEMORY=67108864 \
 -s ENVIRONMENT=web,worker -s FILESYSTEM=0 -s MALLOC=emmalloc -s SUPPORT_LONGJMP=0 \
 -s EXPORTED_RUNTIME_METHODS=HEAPU8 -s EXPORTED_FUNCTIONS=_malloc,_free -msimd128 -flto -Oz -o output/video-q3-codec.mjs
