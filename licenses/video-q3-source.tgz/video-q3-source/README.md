# Q3 decoder corresponding source

Unpack the adjacent seven-part audio-source-v1 package as its notice directs.
The complete official source archives under audio-source/archives/ are shared,
unchanged dependencies listed with exact hashes in shared-source.json. Preserve
those archives and this package together when redistributing the decoder.

Extract the listed FFmpeg archive into this directory's sources/ folder. Activate
a compatible Emscripten 4.0.15 compiler, then run bash relink.sh. This recompiles
the modifiable MIT bridge and relinks supplied LGPL libraries. The resulting
output/video-q3-codec.wasm can replace the decoder for debugging modifications.
No compiler is installed by that recipe. A same-toolchain match is checked
separately; compiler/cache executables are not bundled.

For modified FFmpeg libraries, reconstruct their configuration from the supplied
configuration/config.mak and original-build.sh flags in an isolated source tree,
then compile libavcodec.a and libavutil.a and rerun relink.sh. The original build
script's workstation SDK paths are historical; use your activated toolchain.
Complete upstream copyrights/licenses remain in the shared FFmpeg archive.
Read NOTICE.md and notices/ for modification, debugging and redistribution rights.

The readable product-source files contain this package's snapshot; current
distributed unminified JavaScript remains the preferred adaptation source.
The bridge checks decoded progressive/I420/SAR1:1/BT709 limited metadata and
verifies no delayed frame remains at EOF; source-clock timestamps remain in JS.
This package excludes media fixtures, accounts, compiler cache and SDK binaries.
